# -*- coding: utf-8 -*-
__persistentengine__ = True

import clr
clr.AddReference("PresentationFramework")
clr.AddReference("PresentationCore")
clr.AddReference("WindowsBase")

import math
import System
from System.Collections.Generic import List
from System.Windows.Controls import TreeViewItem, CheckBox, StackPanel, TextBlock, TextBox, Orientation, ComboBox, ComboBoxItem, Button, Canvas
from System.Windows.Shapes import Polyline, Ellipse
from System.Windows.Media import Brushes, PointCollection
from System.Windows import Thickness, TextWrapping, Point

from pyrevit import revit, forms, script
from Autodesk.Revit.UI import IExternalEventHandler, ExternalEvent
from Autodesk.Revit.UI.Selection import ObjectType, ISelectionFilter
from Autodesk.Revit.DB import (
    FilteredElementCollector, BuiltInCategory, FamilySymbol, Transaction,
    HostObjectUtils, ShellLayerType, RevitLinkInstance,
    XYZ, BuiltInParameter, LocationCurve, LocationPoint, ElementId, 
    SpatialElementBoundaryOptions, Reference
)

doc = revit.doc
uidoc = revit.uidoc

# -----------------------------
# Units & Helpers
# -----------------------------
FT_PER_MM = 1.0 / 304.8
def mm_to_ft(mm): return mm * FT_PER_MM

class LinkedWallReferenceFilter(ISelectionFilter):
    def AllowElement(self, e):
        return isinstance(e, RevitLinkInstance)
    def AllowReference(self, r, p):
        try:
            link_inst = doc.GetElement(r.ElementId)
            link_doc = link_inst.GetLinkDocument()
            linked_elem = link_doc.GetElement(r.LinkedElementId)
            return linked_elem and linked_elem.GetType().Name == "Wall"
        except:
            return False

def param_str(elem, bip):
    try:
        p = elem.get_Parameter(bip)
        if p and p.HasValue: return p.AsString()
    except: pass
    return None

def safe_elem_name(elem):
    return (getattr(elem, 'Name', None) or 
            param_str(elem, BuiltInParameter.ALL_MODEL_TYPE_NAME) or 
            str(elem.Id.IntegerValue))

def symbol_display(sym):
    fname = getattr(sym.Family, 'Name', '<Family?>')
    tname = param_str(sym, BuiltInParameter.SYMBOL_NAME_PARAM) or "<Type?>"
    return u"{} :: {}".format(fname, tname)

def collect_workplane_symbols():
    cats = [BuiltInCategory.OST_ElectricalFixtures]
    syms = []
    for cat in cats:
        for s in FilteredElementCollector(doc).OfClass(FamilySymbol).OfCategory(cat).WhereElementIsElementType():
            syms.append(s)
    return list({s.Id.IntegerValue: s for s in syms}.values())

def ensure_symbol_active(sym):
    if not sym.IsActive:
        sym.Activate()
        doc.Regenerate()

def get_space_point(space):
    try:
        loc = space.Location
        if isinstance(loc, LocationPoint): return loc.Point
    except: pass
    bb = space.get_BoundingBox(None)
    return (bb.Min + bb.Max) * 0.5 if bb else XYZ(0, 0, 0)

# --- NEW: Automatically name walls by Compass Direction ---
def compute_friendly_wall_name(link_inst, linked_wall, space):
    options = SpatialElementBoundaryOptions()
    segments_list = space.GetBoundarySegments(options)
    
    matching_curves = []
    if segments_list:
        for b_list in segments_list:
            for seg in b_list:
                if seg.LinkElementId == linked_wall.Id:
                    matching_curves.append(seg.GetCurve())
                    
    if not matching_curves:
        return u"Unbounded Wall ({})".format(linked_wall.Id.IntegerValue)

    matching_curves.sort(key=lambda x: x.Length, reverse=True)
    c = matching_curves[0]
    length_mm = int(c.Length * 304.8)

    space_pt = get_space_point(space)
    mid_pt = c.Evaluate(0.5, True)
    
    v = (mid_pt - space_pt).Normalize()
    angle = math.atan2(v.X, v.Y) * 180 / math.pi
    
    direction = ""
    if -22.5 <= angle <= 22.5: direction = "North"
    elif 22.5 < angle <= 67.5: direction = "North-East"
    elif 67.5 < angle <= 112.5: direction = "East"
    elif 112.5 < angle <= 157.5: direction = "South-East"
    elif angle > 157.5 or angle <= -157.5: direction = "South"
    elif -157.5 < angle <= -112.5: direction = "South-West"
    elif -112.5 < angle <= -67.5: direction = "West"
    elif -67.5 < angle < -22.5: direction = "North-West"
    
    return u"{} Wall (L: {}mm)".format(direction, length_mm)

# -----------------------------
# Data Models
# -----------------------------
class SpaceData(object):
    def __init__(self, space):
        self.space = space
        self.idint = space.Id.IntegerValue
        self.name = safe_elem_name(space)
        self.number = getattr(space, 'Number', '')
        lvl = doc.GetElement(space.LevelId) if space.LevelId else None
        self.level = lvl.Name if lvl else ""
        self.walls = []  

    def display(self):
        return u"{} - {} ({})".format(self.number, self.name, self.level)

class WallData(object):
    def __init__(self, ref_obj, link_inst_id_int, link_wall_id_int, friendly_name):
        self.ref = ref_obj 
        self.link_inst_id = link_inst_id_int
        self.link_wall_id = link_wall_id_int
        self.friendly_name = friendly_name
        self.checked = True
        self.types = []  

    def display(self):
        return self.friendly_name

class TypeData(object):
    def __init__(self, sym_id_int, label, qty, elev_mm, offset_mm, comments):
        self.symbol_id = sym_id_int
        self.label = label
        self.qty = qty
        self.elev = elev_mm
        self.offset = offset_mm
        self.comments = comments

# -----------------------------
# External Event Setup
# -----------------------------
class UiRequest(object):
    def __init__(self):
        self.action = None
        self.payload = None

REQ = UiRequest()

class Handler(IExternalEventHandler):
    def Execute(self, uiapp):
        try:
            if REQ.action: REQ.action(REQ.payload)
        finally:
            REQ.action = None
            REQ.payload = None
    def GetName(self): return "PlaceFixtures"

EXTEVENT = ExternalEvent.Create(Handler())

# -----------------------------
# Placement Logic 
# -----------------------------
def place_on_linked_wall_face(link_inst, linked_wall, space, type_data_list, sym_map, level_elev_ft, end_offset_ft, min_spacing_ft):
    placed_ids = List[ElementId]() 
    link_doc = link_inst.GetLinkDocument()
    
    options = SpatialElementBoundaryOptions()
    segments_list = space.GetBoundarySegments(options)
    
    matching_curves = []
    if segments_list:
        for b_list in segments_list:
            for seg in b_list:
                if seg.LinkElementId == linked_wall.Id:
                    matching_curves.append(seg.GetCurve())
                    
    if not matching_curves:
        return placed_ids

    matching_curves.sort(key=lambda x: x.Length, reverse=True)
    c = matching_curves[0] 
    L = c.Length

    intervals = [[0, L]]
    door_ids = linked_wall.FindInserts(True, False, False, False)
    tf = link_inst.GetTotalTransform()
    
    for did in door_ids:
        door = link_doc.GetElement(did)
        if not door or not door.Category: continue
        if door.Category.Id.IntegerValue != int(BuiltInCategory.OST_Doors): continue
        
        width = mm_to_ft(900) 
        for param in [BuiltInParameter.DOOR_WIDTH, BuiltInParameter.GENERIC_WIDTH, BuiltInParameter.FAMILY_WIDTH_PARAM]:
            p = door.get_Parameter(param)
            if p and p.HasValue: 
                width = p.AsDouble()
                break
            if getattr(door, 'Symbol', None):
                p_sym = door.Symbol.get_Parameter(param)
                if p_sym and p_sym.HasValue:
                    width = p_sym.AsDouble()
                    break
        
        loc = door.Location
        if not isinstance(loc, LocationPoint): continue
        pt_host = tf.OfPoint(loc.Point)
        
        res = c.Project(pt_host)
        if not res: continue
        if res.Distance > width: continue 
        
        frac = c.ComputeNormalizedParameter(res.Parameter)
        d = frac * L
        
        buffer = mm_to_ft(50)
        door_start = d - (width / 2.0) - buffer
        door_end = d + (width / 2.0) + buffer
        
        new_intervals = []
        for inv in intervals:
            if door_end <= inv[0] or door_start >= inv[1]:
                new_intervals.append(inv) 
            else:
                if door_start > inv[0]: new_intervals.append([inv[0], door_start])
                if door_end < inv[1]: new_intervals.append([door_end, inv[1]])
        intervals = new_intervals

    min_space_req = mm_to_ft(600)
    valid_intervals = [inv for inv in intervals if (inv[1] - inv[0]) >= min_space_req]
    
    if not valid_intervals:
        return placed_ids 
        
    valid_intervals.sort(key=lambda x: x[1] - x[0], reverse=True)
    best_inv = valid_intervals[0]
    
    seg_start = best_inv[0]
    seg_end = best_inv[1]
    
    transform_mid = c.ComputeDerivatives(0.5, True)
    tangent_mid = transform_mid.BasisX.Normalize()
    room_inward_normal = XYZ.BasisZ.CrossProduct(tangent_mid).Normalize()
    
    ext_n_host = tf.OfVector(linked_wall.Orientation).Normalize()
    side = ShellLayerType.Exterior if room_inward_normal.DotProduct(ext_n_host) > 0 else ShellLayerType.Interior
    faces = HostObjectUtils.GetSideFaces(linked_wall, side)
    
    if not faces or faces.Count == 0:
        other_side = ShellLayerType.Interior if side == ShellLayerType.Exterior else ShellLayerType.Exterior
        faces = HostObjectUtils.GetSideFaces(linked_wall, other_side)
        if not faces or faces.Count == 0: return placed_ids

    host_face_ref = faces[0].CreateLinkReference(link_inst)
    if not host_face_ref: return placed_ids

    usable = (seg_end - seg_start) - (2.0 * end_offset_ft)
    if usable <= 0: return placed_ids

    total_qty = sum([td.qty for td in type_data_list])
    if total_qty <= 0: return placed_ids

    while total_qty > 1 and (usable / float(total_qty + 1)) < min_spacing_ft:
        total_qty -= 1

    seq = []
    remaining = {td: td.qty for td in type_data_list}
    added_count = 0
    while added_count < total_qty:
        added = False
        for td in type_data_list:
            if remaining[td] > 0 and added_count < total_qty:
                seq.append(td)
                remaining[td] -= 1
                added_count += 1
                added = True
        if not added: break

    for i in range(1, total_qty + 1):
        td = seq[i - 1]
        sym = sym_map.get(td.symbol_id)
        if not sym: continue
        
        ensure_symbol_active(sym)
        
        dist_along_usable = end_offset_ft + usable * (float(i) / float(total_qty + 1))
        total_dist = seg_start + dist_along_usable
        
        t_norm = total_dist / L 
        
        transform = c.ComputeDerivatives(t_norm, True)
        p_host = transform.Origin
        tangent_host = transform.BasisX.Normalize()
        
        ref_dir = tangent_host.Negate() 

        z_ft = level_elev_ft + mm_to_ft(td.elev)
        loc = XYZ(p_host.X, p_host.Y, z_ft)

        try:
            inst = doc.Create.NewFamilyInstance(host_face_ref, loc, ref_dir, sym)
            if inst:
                pcom = inst.get_Parameter(BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS)
                if pcom and not pcom.IsReadOnly:
                    pcom.Set(td.comments)
                
                lvl_id = space.LevelId
                if lvl_id:
                    p_sched = inst.get_Parameter(BuiltInParameter.INSTANCE_SCHEDULE_ONLY_LEVEL_PARAM)
                    if p_sched and not p_sched.IsReadOnly:
                        p_sched.Set(lvl_id)
                    
                    p_fam = inst.get_Parameter(BuiltInParameter.FAMILY_LEVEL_PARAM)
                    if p_fam and not p_fam.IsReadOnly:
                        p_fam.Set(lvl_id)

                p_elev = inst.get_Parameter(BuiltInParameter.INSTANCE_ELEVATION_PARAM)
                if p_elev and not p_elev.IsReadOnly:
                    p_elev.Set(mm_to_ft(td.elev))
                    
                p_offset = inst.get_Parameter(BuiltInParameter.INSTANCE_FREE_HOST_OFFSET_PARAM)
                if p_offset and not p_offset.IsReadOnly:
                    p_offset.Set(mm_to_ft(td.offset))
                
                placed_ids.Add(inst.Id)
        except Exception:
            pass 

    return placed_ids

# -----------------------------
# UI Class
# -----------------------------
class PlaceFixturesWindow(forms.WPFWindow):
    def __init__(self):
        xaml = script.get_bundle_file("ui.xaml")
        forms.WPFWindow.__init__(self, xaml)

        self._spaces = []          
        self._space_map = {}       
        self._current_space = None 
        self._last_placed_ids = List[ElementId]() 

        self._symbols = collect_workplane_symbols()
        self._sym_map = {s.Id.IntegerValue: s for s in self._symbols}
        self._disp_to_symid = {symbol_display(s): s.Id.IntegerValue for s in self._symbols}

        self._family_controls = [] 

        self._wire_events()
        self._load_types()
        self._load_spaces()
        self._refresh_tree()
        self.txtStatus.Text = "Ready. Select a space."

    def _wire_events(self):
        self.btnClose.Click += lambda s,a: self.Close()
        self.btnReloadSpaces.Click += self._on_reload_spaces
        self.btnPickWalls.Click += self._on_pick_walls
        self.btnClearWalls.Click += self._on_clear_walls
        self.btnAddTypes.Click += self._on_add_types
        self.btnPlace.Click += self._on_place
        self.btnUndoPlace.Click += self._on_undo_place

        self.cbActiveView.Checked += lambda s,a: self._rebuild_space_list()
        self.cbActiveView.Unchecked += lambda s,a: self._rebuild_space_list()
        self.tbSpaceSearch.TextChanged += lambda s,a: self._rebuild_space_list()
        self.lbSpaces.SelectionChanged += self._on_space_changed
        self.tvConfig.SelectedItemChanged += self._on_tree_selection_changed

        # Wall mini-map: redraw when the canvas resizes
        self.canvasWallMap.SizeChanged += lambda s,a: self._redraw_wall_map()

        # Clean up Revit selection when the tool window is closed
        self.Closed += self._on_window_closed

    # -----------------------------
    # Wall mini-map
    # -----------------------------
    def _curve_to_canvas_polyline(self, curve, to_canvas_fn, samples=24):
        """Sample a Revit Curve at `samples`+1 t-values and return a WPF
        Polyline whose Points are the canvas-space (X, flipped Y) of those
        samples. Works uniformly for Line, Arc, etc."""
        pl = Polyline()
        pts = PointCollection()
        for i in range(samples + 1):
            t = i / float(samples)
            try:
                p = curve.Evaluate(t, True)
            except Exception:
                continue
            cx, cy = to_canvas_fn(p.X, p.Y)
            pts.Add(Point(cx, cy))
        pl.Points = pts
        return pl

    def _redraw_wall_map(self):
        """Draw a top-down vector diagram of the current space's picked walls
        on canvasWallMap, with numbered labels (1..N) matching the order of
        walls shown in the tree view."""
        cnv = self.canvasWallMap
        cnv.Children.Clear()

        if not self._current_space:
            return
        walls = self._current_space.walls

        # Show a placeholder if nothing to draw yet
        if not walls:
            tb = TextBlock()
            tb.Text = "(No walls picked for this space yet)"
            tb.Foreground = Brushes.Gray
            tb.FontStyle = System.Windows.FontStyles.Italic
            Canvas.SetLeft(tb, 10)
            Canvas.SetTop(tb, 10)
            cnv.Children.Add(tb)
            return

        space = self._current_space.space

        # ---- collect curves ----
        # outline_curves : every boundary segment of the space (light grey context)
        # wall_to_curves : link-wall-id -> [curves]   (for picked walls)
        outline_curves = []
        wall_to_curves = {}
        try:
            seg_lists = space.GetBoundarySegments(SpatialElementBoundaryOptions())
        except Exception:
            seg_lists = None

        if seg_lists:
            for loop in seg_lists:
                for seg in loop:
                    try:
                        c = seg.GetCurve()
                        outline_curves.append(c)
                        if seg.LinkElementId != ElementId.InvalidElementId:
                            wid = seg.LinkElementId.IntegerValue
                            wall_to_curves.setdefault(wid, []).append(c)
                    except Exception:
                        pass

        # For each picked wall, pick the longest matching boundary segment.
        # If no boundary segment matches (e.g. the wall doesn't actually bound
        # the space), fall back to the wall's location curve transformed to
        # host coords so the wall still appears on the map.
        items = []
        for idx, wd in enumerate(walls, start=1):
            curves = wall_to_curves.get(wd.link_wall_id, [])
            chosen = None
            if curves:
                chosen = sorted(curves, key=lambda c: c.Length, reverse=True)[0]
            else:
                try:
                    link_inst = doc.GetElement(ElementId(wd.link_inst_id))
                    if link_inst:
                        link_doc = link_inst.GetLinkDocument()
                        if link_doc:
                            lw = link_doc.GetElement(ElementId(wd.link_wall_id))
                            if lw and isinstance(lw.Location, LocationCurve):
                                chosen = lw.Location.Curve.CreateTransformed(
                                    link_inst.GetTotalTransform())
                except Exception:
                    chosen = None
            if chosen is not None:
                items.append((idx, wd, chosen))

        if not items and not outline_curves:
            return

        # ---- compute world bounds ----
        all_pts = []
        for c in outline_curves:
            for t in (0.0, 0.25, 0.5, 0.75, 1.0):
                try:
                    p = c.Evaluate(t, True)
                    all_pts.append((p.X, p.Y))
                except Exception:
                    pass
        for _, _, c in items:
            for t in (0.0, 0.5, 1.0):
                try:
                    p = c.Evaluate(t, True)
                    all_pts.append((p.X, p.Y))
                except Exception:
                    pass
        if not all_pts:
            return

        xs = [p[0] for p in all_pts]
        ys = [p[1] for p in all_pts]
        minx, maxx = min(xs), max(xs)
        miny, maxy = min(ys), max(ys)
        w = maxx - minx
        h = maxy - miny
        if w < 1e-6: w = 1.0
        if h < 1e-6: h = 1.0

        # ---- map world -> canvas ----
        cw = cnv.ActualWidth if cnv.ActualWidth > 0 else 320
        ch_ = cnv.ActualHeight if cnv.ActualHeight > 0 else 200
        padding = 28
        avail_w = max(1.0, cw - 2 * padding)
        avail_h = max(1.0, ch_ - 2 * padding)
        scale = min(avail_w / w, avail_h / h)
        draw_w = w * scale
        draw_h = h * scale
        off_x = (cw - draw_w) / 2.0
        off_y = (ch_ - draw_h) / 2.0

        def to_canvas(wx, wy):
            cx = (wx - minx) * scale + off_x
            cy = ch_ - ((wy - miny) * scale + off_y)
            return cx, cy

        # ---- draw space outline (light grey) ----
        for c in outline_curves:
            try:
                pl = self._curve_to_canvas_polyline(c, to_canvas, samples=12)
                pl.Stroke = Brushes.LightGray
                pl.StrokeThickness = 1.0
                cnv.Children.Add(pl)
            except Exception:
                pass

        # ---- centre of space (used to push labels outward) ----
        try:
            sp_pt = get_space_point(space)
            sp_x, sp_y = sp_pt.X, sp_pt.Y
        except Exception:
            sp_x, sp_y = (minx + maxx) * 0.5, (miny + maxy) * 0.5

        # ---- draw each picked wall + numbered label ----
        for idx, wd, curve in items:
            try:
                pl = self._curve_to_canvas_polyline(curve, to_canvas, samples=24)
                if wd.checked:
                    pl.Stroke = Brushes.OrangeRed
                    pl.StrokeThickness = 4.0
                else:
                    pl.Stroke = Brushes.Gray
                    pl.StrokeThickness = 2.0
                cnv.Children.Add(pl)

                # midpoint of the wall in world coords
                try:
                    mid = curve.Evaluate(0.5, True)
                except Exception:
                    mid = curve.GetEndPoint(0)
                mx_canvas, my_canvas = to_canvas(mid.X, mid.Y)

                # outward direction = from space centre toward wall midpoint
                ox = mid.X - sp_x
                oy = mid.Y - sp_y
                olen = math.sqrt(ox * ox + oy * oy)
                if olen > 1e-6:
                    ox /= olen
                    oy /= olen
                else:
                    ox, oy = 1.0, 0.0

                offset_px = 16
                # canvas Y is flipped: a +Y world offset becomes a -Y canvas offset
                lbl_x = mx_canvas + ox * offset_px
                lbl_y = my_canvas - oy * offset_px

                r = 11
                circ = Ellipse()
                circ.Width = r * 2
                circ.Height = r * 2
                circ.Fill = Brushes.White
                circ.Stroke = Brushes.OrangeRed if wd.checked else Brushes.Gray
                circ.StrokeThickness = 2.0
                Canvas.SetLeft(circ, lbl_x - r)
                Canvas.SetTop(circ, lbl_y - r)
                cnv.Children.Add(circ)

                num = TextBlock()
                num.Text = str(idx)
                num.FontWeight = System.Windows.FontWeights.Bold
                num.FontSize = 11
                num.Foreground = Brushes.OrangeRed if wd.checked else Brushes.Gray
                num.TextAlignment = System.Windows.TextAlignment.Center
                num.Width = r * 2
                Canvas.SetLeft(num, lbl_x - r)
                Canvas.SetTop(num, lbl_y - r + 1)
                cnv.Children.Add(num)
            except Exception:
                pass

    def _make_wall_check_handler(self, wd, value):
        """Closure-safe handler for wall CheckBox toggles. Also refreshes the
        mini-map so the orange/grey state matches."""
        def _h(s, a):
            wd.checked = value
            self._redraw_wall_map()
        return _h

    def _on_window_closed(self, s, a):
        """Clear any highlight we left in the active view when the tool exits."""
        def act(ui):
            try:
                uidoc.Selection.SetElementIds(List[ElementId]())
            except Exception:
                pass
        REQ.action = act
        REQ.payload = self
        EXTEVENT.Raise()

    def _highlight_current_space_walls(self):
        """Set Revit's selection to all walls of the current space, giving each
        of them Revit's native selection highlight (cyan/blue) in the active
        view. Persists until the user clicks elsewhere in the model.

        Note: Revit's View.SetElementOverrides does not accept linked element
        IDs, so a per-element coloured override is not available for linked
        walls — selection is the supported way to visually distinguish them.
        """
        def act(ui):
            try:
                refs = List[Reference]()
                if ui._current_space:
                    for wd in ui._current_space.walls:
                        if wd.ref is not None:
                            try:
                                refs.Add(wd.ref)
                            except Exception:
                                pass
                if refs.Count > 0:
                    uidoc.Selection.SetReferences(refs)
                else:
                    uidoc.Selection.SetElementIds(List[ElementId]())
            except Exception:
                pass
        REQ.action = act
        REQ.payload = self
        EXTEVENT.Raise()

    def _set_status(self, text):
        self.Dispatcher.Invoke(System.Action(lambda: setattr(self.txtStatus, "Text", text)))

    def _load_types(self):
        self.spFamilies.Children.Clear()
        self._family_controls = []
        
        families = {}
        for s in self._symbols:
            fname = getattr(s.Family, 'Name', '<Family?>')
            if fname not in families:
                families[fname] = []
            families[fname].append(s)
            
        for fname in sorted(families.keys()):
            panel = StackPanel()
            panel.Orientation = Orientation.Horizontal
            panel.Margin = Thickness(0, 2, 0, 2)
            
            cb = CheckBox()
            cb.VerticalAlignment = System.Windows.VerticalAlignment.Center
            cb.Margin = Thickness(0, 0, 8, 0)
            
            lbl = TextBlock()
            lbl.Text = fname
            lbl.Width = 140
            lbl.TextWrapping = TextWrapping.Wrap
            lbl.Margin = Thickness(0, 0, 8, 0)
            lbl.VerticalAlignment = System.Windows.VerticalAlignment.Center
            
            cmb = ComboBox()
            cmb.Width = 140
            cmb.VerticalAlignment = System.Windows.VerticalAlignment.Center
            
            types = sorted(families[fname], key=lambda x: param_str(x, BuiltInParameter.SYMBOL_NAME_PARAM) or "")
            for t in types:
                tname = param_str(t, BuiltInParameter.SYMBOL_NAME_PARAM) or "<Type?>"
                cbi = ComboBoxItem()
                cbi.Content = tname
                cbi.Tag = t.Id.IntegerValue
                cmb.Items.Add(cbi)
                
            if cmb.Items.Count > 0:
                cmb.SelectedIndex = 0
                
            panel.Children.Add(cb)
            panel.Children.Add(lbl)
            panel.Children.Add(cmb)
            
            self.spFamilies.Children.Add(panel)
            self._family_controls.append((cb, cmb))

    def _load_spaces(self):
        self._spaces = []
        for sp in FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_MEPSpaces).WhereElementIsNotElementType():
            self._spaces.append(SpaceData(sp))
        self._spaces.sort(key=lambda x: (x.number, x.name))
        self._rebuild_space_list()

    def _rebuild_space_list(self):
        f = (self.tbSpaceSearch.Text or "").strip().lower()
        filter_view = bool(self.cbActiveView.IsChecked)

        view_space_ids = set()
        if filter_view and doc.ActiveView:
            try:
                view_space_ids = {e.Id.IntegerValue for e in FilteredElementCollector(doc, doc.ActiveView.Id).OfCategory(BuiltInCategory.OST_MEPSpaces)}
            except:
                pass

        self.lbSpaces.Items.Clear()
        self._space_map = {}
        for sd in self._spaces:
            if filter_view and sd.idint not in view_space_ids: 
                continue
            
            disp = sd.display()
            if f and (f not in disp.lower()): continue
            
            self.lbSpaces.Items.Add(disp)
            self._space_map[disp] = sd

    def _on_reload_spaces(self, s, a):
        self._load_spaces()
        self._refresh_tree()
        self.txtStatus.Text = "Spaces reloaded."

    def _on_space_changed(self, s, a):
        disp = self.lbSpaces.SelectedItem
        if disp and disp in self._space_map:
            self._current_space = self._space_map[disp]
            self._refresh_tree()
            self._highlight_current_space_walls()
            n = len(self._current_space.walls)
            if n:
                self.txtStatus.Text = "Selected space: {} ({} wall(s) highlighted)".format(disp, n)
            else:
                self.txtStatus.Text = "Selected space: {} (no walls picked yet)".format(disp)

    def _on_tree_selection_changed(self, s, a):
        item = self.tvConfig.SelectedItem
        if not item: return
        tag = item.Tag

        if isinstance(tag, WallData) or isinstance(tag, SpaceData):
            def highlight(ui):
                try:
                    if isinstance(tag, SpaceData):
                        ids = List[ElementId]()
                        ids.Add(ElementId(tag.idint))
                        uidoc.Selection.SetElementIds(ids)
                    elif isinstance(tag, WallData):
                        refs = List[Reference]()
                        refs.Add(tag.ref)
                        uidoc.Selection.SetReferences(refs)
                except Exception:
                    pass

            REQ.action = highlight
            REQ.payload = self
            EXTEVENT.Raise()

    def _on_pick_walls(self, s, a):
        if not self._current_space: return
        self.txtStatus.Text = "Pick linked walls, then Finish."
        self.Hide()

        def act(ui):
            try:
                refs = uidoc.Selection.PickObjects(ObjectType.LinkedElement, LinkedWallReferenceFilter(), "Pick walls (Finish)")
                ui.Dispatcher.Invoke(System.Action(lambda: ui._finish_pick_walls(refs, "Picked {} wall(s).".format(len(refs)))))
            except:
                ui.Dispatcher.Invoke(System.Action(lambda: ui._finish_pick_walls(None, "Pick Walls cancelled.")))
        
        REQ.action = act
        REQ.payload = self
        EXTEVENT.Raise()
        
    def _finish_pick_walls(self, refs, msg):
        self.Show()
        self.Activate()
        self.txtStatus.Text = msg
        if refs and self._current_space:
            self._current_space.walls = []
            for r in refs: 
                try:
                    link_inst = doc.GetElement(r.ElementId)
                    linked_wall = link_inst.GetLinkDocument().GetElement(r.LinkedElementId)
                    fname = compute_friendly_wall_name(link_inst, linked_wall, self._current_space.space)
                except Exception:
                    fname = u"Unknown Wall ({})".format(r.LinkedElementId.IntegerValue)
                self._current_space.walls.append(WallData(r, r.ElementId.IntegerValue, r.LinkedElementId.IntegerValue, fname))
            self._refresh_tree()
            self._highlight_current_space_walls()

    def _on_clear_walls(self, s, a):
        if self._current_space:
            self._current_space.walls = []
            self._refresh_tree()
            self._highlight_current_space_walls()
            self.txtStatus.Text = "Cleared walls."

    def _on_add_types(self, s, a):
        if not self._current_space or not self._current_space.walls: return
        
        sel_ids = []
        for cb, cmb in self._family_controls:
            if cb.IsChecked:
                sel_item = cmb.SelectedItem
                if sel_item:
                    sel_ids.append(sel_item.Tag)
                    
        if not sel_ids:
            self.txtStatus.Text = "Check at least one family to add."
            return

        try: qty = max(0, int(self.tbDefaultQty.Text))
        except: qty = 1
        
        try: elev = float(self.tbElevation.Text)
        except: elev = 300.0

        try: offset = float(self.tbHostOffset.Text)
        except: offset = 0.0

        cmt = self.tbComments.Text or ""

        affected = 0
        for w in self._current_space.walls:
            if w.checked:
                for sid in sel_ids:
                    w.types.append(TypeData(sid, symbol_display(self._sym_map[sid]), qty, elev, offset, cmt))
                affected += 1

        self._refresh_tree()
        self.txtStatus.Text = "Added type(s) to {} wall(s).".format(affected)

    def _on_place(self, s, a):
        def act(ui):
            try: end_ft = mm_to_ft(float(ui.tbEndOffset.Text))
            except: end_ft = mm_to_ft(300.0)
            try: min_ft = mm_to_ft(float(ui.tbMinSpacing.Text))
            except: min_ft = mm_to_ft(250.0)

            all_placed_ids = List[ElementId]() 
            
            tx = Transaction(doc, "Place Fixtures Individually")
            tx.Start()
            try:
                for spd in ui._spaces:
                    if not spd.walls: continue
                    lvl = doc.GetElement(spd.space.LevelId) if spd.space.LevelId else None
                    level_elev = lvl.Elevation if lvl else 0.0

                    for wd in spd.walls:
                        if not wd.checked: continue
                        valid_types = [td for td in wd.types if td.qty > 0]
                        if not valid_types: continue

                        link_inst = doc.GetElement(ElementId(wd.link_inst_id))
                        linked_wall = link_inst.GetLinkDocument().GetElement(ElementId(wd.link_wall_id)) if link_inst else None
                        
                        if link_inst and linked_wall:
                            new_ids = place_on_linked_wall_face(link_inst, linked_wall, spd.space, valid_types, ui._sym_map, level_elev, end_ft, min_ft)
                            if new_ids.Count > 0:
                                all_placed_ids.AddRange(new_ids)
            finally:
                tx.Commit()
            
            ui._last_placed_ids = all_placed_ids
            ui.Dispatcher.Invoke(System.Action(lambda: setattr(ui.btnUndoPlace, "IsEnabled", all_placed_ids.Count > 0)))

            if all_placed_ids.Count > 0:
                uidoc.Selection.SetElementIds(all_placed_ids)

            ui._set_status("Placed {} fixtures.".format(all_placed_ids.Count))

        REQ.action = act
        REQ.payload = self
        EXTEVENT.Raise()
        
    def _on_undo_place(self, s, a):
        if not self._last_placed_ids or self._last_placed_ids.Count == 0:
            return
            
        def act(ui):
            tx = Transaction(doc, "Undo Last Fixture Placement")
            tx.Start()
            deleted = 0
            try:
                for eid in ui._last_placed_ids:
                    if doc.GetElement(eid):
                        doc.Delete(eid)
                        deleted += 1
            finally:
                tx.Commit()
            
            ui._last_placed_ids.Clear()
            ui.Dispatcher.Invoke(System.Action(lambda: setattr(ui.btnUndoPlace, "IsEnabled", False)))
            ui._set_status("Removed {} previously placed fixtures.".format(deleted))
            
        REQ.action = act
        REQ.payload = self
        EXTEVENT.Raise()

    def _refresh_tree(self):
        self.tvConfig.Items.Clear()
        if not self._current_space: return

        root = TreeViewItem()
        root.Header = u"SPACE: {} {}".format(self._current_space.number, self._current_space.name)
        root.IsExpanded = True
        root.Tag = self._current_space 

        for idx, wd in enumerate(self._current_space.walls, start=1):
            w_item = TreeViewItem()
            w_item.IsExpanded = True
            w_item.Tag = wd 
            
            cb = CheckBox()
            cb.Content = u"{}. {}".format(idx, wd.display())
            cb.IsChecked = wd.checked
            cb.Checked += self._make_wall_check_handler(wd, True)
            cb.Unchecked += self._make_wall_check_handler(wd, False)
            w_item.Header = cb

            for td in wd.types:
                t_item = TreeViewItem()
                t_item.Tag = td
                
                panel = StackPanel()
                panel.Orientation = Orientation.Horizontal
                panel.Margin = Thickness(0,2,0,2)

                cmb_type = ComboBox()
                cmb_type.Width = 160
                cmb_type.Margin = Thickness(0,0,10,0)
                cmb_type.VerticalAlignment = System.Windows.VerticalAlignment.Center

                for sym in sorted(self._symbols, key=lambda x: symbol_display(x)):
                    cbi = ComboBoxItem()
                    cbi.Content = symbol_display(sym)
                    cbi.Tag = sym.Id.IntegerValue
                    cmb_type.Items.Add(cbi)
                    if sym.Id.IntegerValue == td.symbol_id:
                        cmb_type.SelectedItem = cbi

                def make_type_changed_handler(tdata):
                    def _h(sender, args):
                        sel = sender.SelectedItem
                        if sel:
                            tdata.symbol_id = sel.Tag
                            tdata.label = sel.Content
                    return _h

                cmb_type.SelectionChanged += make_type_changed_handler(td)

                txt_qty = TextBox()
                txt_qty.Text = str(td.qty)
                txt_qty.Width = 30
                txt_qty.Margin = Thickness(0,0,10,0)
                txt_qty.LostFocus += lambda s,a,t=td: setattr(t, 'qty', max(0, int(s.Text)) if s.Text.isdigit() else 0)

                lbl_elev = TextBlock()
                lbl_elev.Text = "Z:"
                lbl_elev.VerticalAlignment = System.Windows.VerticalAlignment.Center
                txt_elev = TextBox()
                txt_elev.Text = str(td.elev)
                txt_elev.Width = 40
                txt_elev.Margin = Thickness(0,0,10,0)
                txt_elev.LostFocus += lambda s,a,t=td: setattr(t, 'elev', float(s.Text) if s.Text.replace('.','',1).isdigit() else t.elev)

                lbl_off = TextBlock()
                lbl_off.Text = "Off:"
                lbl_off.VerticalAlignment = System.Windows.VerticalAlignment.Center
                txt_off = TextBox()
                txt_off.Text = str(td.offset)
                txt_off.Width = 35
                txt_off.Margin = Thickness(0,0,10,0)
                txt_off.LostFocus += lambda s,a,t=td: setattr(t, 'offset', float(s.Text) if s.Text.replace('.','',1).replace('-','',1).isdigit() else t.offset)

                lbl_cmt = TextBlock()
                lbl_cmt.Text = "Cmt:"
                lbl_cmt.VerticalAlignment = System.Windows.VerticalAlignment.Center
                txt_cmt = TextBox()
                txt_cmt.Text = td.comments
                txt_cmt.Width = 100
                txt_cmt.LostFocus += lambda s,a,t=td: setattr(t, 'comments', s.Text)
                
                btn_remove = Button()
                btn_remove.Content = "X"
                btn_remove.Width = 20
                btn_remove.Margin = Thickness(10,0,0,0)
                btn_remove.Foreground = Brushes.Red
                btn_remove.FontWeight = System.Windows.FontWeights.Bold
                
                def make_remove_handler(wall_data, type_data):
                    def _h(sender, args):
                        if type_data in wall_data.types:
                            wall_data.types.remove(type_data)
                            self._refresh_tree()
                    return _h
                    
                btn_remove.Click += make_remove_handler(wd, td)

                panel.Children.Add(cmb_type) 
                panel.Children.Add(TextBlock(Text="Qty:", VerticalAlignment=System.Windows.VerticalAlignment.Center))
                panel.Children.Add(txt_qty)
                panel.Children.Add(lbl_elev)
                panel.Children.Add(txt_elev)
                panel.Children.Add(lbl_off)
                panel.Children.Add(txt_off)
                panel.Children.Add(lbl_cmt)
                panel.Children.Add(txt_cmt)
                panel.Children.Add(btn_remove) 

                t_item.Header = panel
                w_item.Items.Add(t_item)

            root.Items.Add(w_item)
        self.tvConfig.Items.Add(root)
        self._redraw_wall_map()

ui = PlaceFixturesWindow()
ui.Show()